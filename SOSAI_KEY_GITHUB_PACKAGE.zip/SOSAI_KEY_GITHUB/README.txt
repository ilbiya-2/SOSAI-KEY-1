SOSAI KEY – GitHub Pages package

FILES
- index.html — the interactive 3D website
- SOSAI_KEY_INTERACTIVE.glb — improved GLB model

HOW TO USE WITH GITHUB
1. Create/open your GitHub repository.
2. Upload BOTH files into the same folder (normally the repository root).
3. In GitHub: Settings → Pages → Deploy from a branch → choose your main branch and /root.
4. Save and open the GitHub Pages URL.

INTERACTION
- Drag the model to rotate it.
- Scroll to zoom.
- Click the physical SOS button on the 3D model.
- The button depresses, the red indicator pulses, and the presentation workflow runs:
  SOS activated → Gathering information → AI verification → GPS + emergency alert.

NOTE
The emergency workflow is a presentation simulation only. It does not contact emergency services or transmit real GPS/sensor data.
